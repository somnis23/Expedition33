// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BattleUnitActor.h"
#include "GameFramework/Actor.h"
#include "BattleEnemyActor.generated.h"

UCLASS()
class EXPEDITION33_API ABattleEnemyActor : public ABattleUnitActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ABattleEnemyActor();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	virtual void OnTurnStart() override;
};
