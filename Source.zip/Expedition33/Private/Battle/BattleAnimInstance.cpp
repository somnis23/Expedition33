// Fill out your copyright notice in the Description page of Project Settings.


#include "Battle/BattleAnimInstance.h"

#include "BattleUnitActor.h"


// Enemy battle 에 현재 상태 기억용
void UBattleAnimInstance::SetEnemyPhase(EEnemyTurnPhase NewPhase)
{
	EnemyPhase = NewPhase;
	
}

void UBattleAnimInstance::SetPlannedAttack(EEnemyAttackType NewType)
{
	PlannedAttack = NewType; 
	
}

void UBattleAnimInstance::SetTurnState(EBattleTurnState NewState, bool bMyTurn ,bool bPlayerTurnStar)
{
	TurnState = NewState;
	bIsMyTurn = bMyTurn;
	bPlayerTurnStart = bPlayerTurnStar;
	
	if (bPlayerTurnStar)
	{
		bTurnStartRequest = true;
	}
	
	UE_LOG(LogTemp, Warning,
		TEXT("Anim TurnState=%d, bIsMyTurn=%s"),
		(int32)TurnState,
		bIsMyTurn ? TEXT("true") : TEXT("false")
	);
}

void UBattleAnimInstance::RequestAttack()
{
	if (bAttackRequest) return; // 중복 방지

	UE_LOG(LogTemp, Warning, TEXT("[Anim] Attack Requested"));
	
	bAttackRequest = true;
	
}

void UBattleAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);
	
	if (bAttackRequest)
	{
		// 이번 프레임 전이를 태우고 바로 끈다 (펄스)
		bAttackRequest = false;
	}

	if (bTurnStartRequest)
	{
		bTurnStartRequest = false;
	}
}

void UBattleAnimInstance::OnAttackAnimFinished()
{
	UE_LOG(LogTemp, Warning, TEXT("[Anim] Attack End"));

	AActor* OwnerActor = GetOwningActor();
	
	if (ABattleUnitActor* Unit =
		Cast<ABattleUnitActor>(OwnerActor))
	{
		Unit->OnAttackFinished();
	}
	
}
